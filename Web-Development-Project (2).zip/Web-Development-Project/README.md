# Web-Development-Project
The project is a college prediction system with a login page and predictor system.  The project works on HTML, CSS, JavaScript, PHP, MySQL on Apache server using XAMPP. 
